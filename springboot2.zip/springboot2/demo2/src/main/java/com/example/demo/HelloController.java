package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * HelloController is a simple REST controller for the Spring Boot application.
 * It handles HTTP requests and returns a string response.
 */
@RestController
public class HelloController {

    /**
     * Handles GET requests to the /hello endpoint.
     * @return A greeting message.
     */
    @GetMapping("/hello")
    public String greet() {
        // This string will be sent back as the HTTP response body.
        return "Hello, Anthony's Spring Boot Challenge is WORKING! - After having several version issues lol";
    }

    /**
     * Handles GET requests to the root path /.
     * @return A welcome message.
     */
    @GetMapping("/")
    public String home() {
        return "Welcome to the Spring Boot App! Try navigating to /hello";
    }
}